/*
 * Class: CMSC203 
 * Instructor: Prof. Thai
 * Description: The class sets up a guessing game between the program and the user
 * Due: 10/29/2023
 * Platform/compiler:
 * I pledge that I have completed the programming assignment 
* independently. I have not copied the code from a student or   * any source. I have not given my code to any student.
 * Print your Name here: Ankit Guliani
*/

import java.util.Scanner;
import java.util.Random;
/**
 * Creates ESP guessing class
 *
 */
public class ESPGame {
	//sets up variables for colors
	final String COLOR_RED = "Red";
	final String COLOR_BLUE = "BLUE";
	final String COLOR_GREEN = "GREEN";
	final String COLOR_ORANGE = "Orange";
	final String COLOR_YELLOW = "Yellow";
	final String COLOR_BLACK = "BLACK";
	final String COLOR_WHITE = "White";
	//sets up keyboard input
	String tempLine;
	Scanner keyboard = new Scanner(System.in);
	System.out.println("Enter your name:");
	tempLine = keyboard.nextLine();
	System.out.println("Enter your MCID:");
	tempLine = keyboard.nextLine();
	System.out.println("Tell me something about yourself:");
	tempLine = keyboard.nextLine();
	System.out.println("When is the due date? Enter in MM/DD/YY format");
	tempLine = keyboard.nextLine();
	//creates random object and string to hold testing color
	Random randNum = new Random();
	String myColor;
	int posCount = 0;
	//loops questions to user and adds to count
	for(int i = 0; i<11; i++) {
		System.out.println("/nRound "+i);
		System.out.println("I am thinking of a color./n Which color is it?/nEnter your guess:");
		int randNumHolder = randNum.randInt(7);
		tempLine = keyboard.nextLine();
		switch (randNumHolder) {
		case 1: myColor = COLOR_RED;
		case 2: myColor = COLOR_BLUE;
		case 3: myColor = COLOR_GREEN;
		case 4: myColor = COLOR_ORANGE;
		case 5: myColor = COLOR_YELLOW;
		case 6: myColor = COLOR_BLACK;
		case 7: myColor = COLOR_WHITE;
		if(myColor==tempLine) {
		posCount+=1;
		}
		System.out.println("I was thinking of"+myColor);
		System.out.println("/n You guessed "+ posCount+ "out of 10 correctly.");
	}
	}
	
}
}