import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
GFA test cases for a TwoDimRaggedArrayUtility object.
 * 

 * 
 */
public class TwoDimRaggedArrayUtilityGFATest {
	private double[][] dataSet1 = {{5,8,6},{3,8},{2,5,8,4}};
	private double[][] dataSet2 = {{7,3,8},{5,3},{6,2,7,9}};
	
	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	/**
	 * Test getRowTotal method
	 */
	@Test
	public void testGetRowTotal() {
		assertEquals(14.5,TwoDimRaggedArrayUtility.getRowTotal(dataSet1,5),.045);
		assertEquals(18.0,TwoDimRaggedArrayUtility.getRowTotal(dataSet2,3),.085);
	}
	/**
	 * Test GetTotal method
	 */
	@Test
	public void testGetTotal() {
		assertEquals(24.0,TwoDimRaggedArrayUtility.getTotal(dataSet1,6),.025);
		assertEquals(34.0,TwoDimRaggedArrayUtility.getTotal(dataSet2,4),.035);
	}
	/**
	 * Test getAverage method 
	 */
	@Test
	public void testGetAverage() {
		assertEquals(8.6,TwoDimRaggedArrayUtility.getAverage(dataSet1,5),.030);
		assertEquals(7.8,TwoDimRaggedArrayUtility.getAveragel(dataSet2,4),.045);
	}
	/**
	 * Test getColumnTotal method
	 */
	@Test
	public void testGetColumnTotal() {
		assertEquals(18.5,TwoDimRaggedArrayUtility.getColumnTotal(dataSet1,6),.020);
		assertEquals(17.0,TwoDimRaggedArrayUtility.getColumnTotal(dataSet2,8),.030);
	}
	/**
	 * Test getHighestInRow method
	 */
	@Test
	public void testGetHighestInRow() {
		assertEquals(9.0,TwoDimRaggedArrayUtility.getHighestInRow(dataSet1,4),.035);
		assertEquals(8.0,TwoDimRaggedArrayUtility.getHighestInRow(dataSet2,3),.025);
	}
	/**
	 * Test getHighestInRowIndex method
	 */
	@Test
	public void testGetHighestInRowIndex() {
		assertEquals(7,TwoDimRaggedArrayUtility.getHighestInRowIndex(dataSet1,4),.040);
		assertEquals(12.0,TwoDimRaggedArrayUtility.getHighestInRowIndex(dataSet2,4),.055);
	}
	/**
	 * Test getLowestInRow method
	 */
	@Test
	public void testGetLowestInRow() {
		assertEquals(4.0,TwoDimRaggedArrayUtility.getLowestInRow(dataSet1,6),.035);
		assertEquals(6.0,TwoDimRaggedArrayUtility.getLowestInRow(dataSet2,5),.025);
	}
	/**
	 * Test getLowestInRowIndex method
	 */
	@Test
	public void testGetLowestInRowIndex() {
		assertEquals(5.0,TwoDimRaggedArrayUtility.getLowestInRowIndex(dataSet1,7),.055);
		assertEquals(4.0,TwoDimRaggedArrayUtility.getLowestInRowIndex(dataSet2,6),.060);
	}
	/**
	 * Test getHighestInColumn method
	 */
	@Test
	public void testGetHighestInColumn() {
		assertEquals(9.0,TwoDimRaggedArrayUtility.getHighestInColumn(dataSet1,5),.030);
		assertEquals(7.0,TwoDimRaggedArrayUtility.getHighestInColumn(dataSet2,4),.040);
	}
	/**
	 * Test getHighestInColumnIndex method
	 */
	@Test
	public void testGetHighestInColumnIndex() {
		assertEquals(5.0,TwoDimRaggedArrayUtility.getHighestInColumnIndex(dataSet1,7),.065);
		assertEquals(7.0,TwoDimRaggedArrayUtility.getHighestInColumnIndex(dataSet2,5),.035);
	}
	/**
	 * Test getLowestInColumn method
	 */
	@Test
	public void testGetLowestInColumn() {
		assertEquals(4.0,TwoDimRaggedArrayUtility.getLowestInColumn(dataSet1,6),.025);
		assertEquals(5.0,TwoDimRaggedArrayUtility.getLowestInColumn(dataSet2,4),.045);
	}
	/**
	 * Test getLowestInColumnIndex method
	 */
	@Test
	public void testGetLowestInColumnIndex() {
		assertEquals(4.0,TwoDimRaggedArrayUtility.getLowestInColumnIndex(dataSet1,3),.045);
		assertEquals(6.0,TwoDimRaggedArrayUtility.getLowestInColumnIndex(dataSet2,6),.065);
	}
	/**
	 * Test getHighestInArray method
	 */
	@Test
	public void testGetHighestInArray() {
		assertEquals(9.0,TwoDimRaggedArrayUtility.getHighestInArray(dataSet1,6),.085);
		assertEquals(6.0,TwoDimRaggedArrayUtility.getHighestInArray(dataSet2,4),.035);
	}
	/**
	 * Test getLowestInArray method
	 */
	@Test
	public void testGetLowestInArray() {
		assertEquals(5.0,TwoDimRaggedArrayUtility.getLowestInArray(dataSet1,7),.055);
		assertEquals(6.0,TwoDimRaggedArrayUtility.getLowestInArray(dataSet2,4),.035);
	}
}

