import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;


import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 *GFA test cases for a HolidayBonus object.
 * 
 * 
 * 
 */
public class HolidayBonusGFATest {

	private double[][] dataSet1 = { { 21, 32, 43 }, { 54, 65 }, { 56, 47, 38 } };
	private double[][] dataSet2 = { { 48, 96, 82 }, { 95, 74 }, { 45, 55, 70 } };
	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testCalculateHolidayBonusA() {
		try {
			double[] result = HolidayBonus.calculateHolidayBonus(dataSet1);
			assertEquals(47850.5, result[0], .045);
			assertEquals(75350.25, result[1], .067);
			assertEquals(85340.0, result[2], .088);
		} catch (Exception e) {
			fail("This should not have caused an Exception");
		}
		try {
			double[] result = HolidayBonus.calculateHolidayBonus(dataSet2);
			assertEquals(70585.0, result[0], .080);
			assertEquals(112525.0, result[1], .055);
			assertEquals(145265.5, result[2], .060);
		} catch (Exception e) {
			fail("This should not have caused an Exception");
		}

	}

	@Test
	public void testCalculateTotalHolidayBonusA() {
		assertEquals(10545.0, HolidayBonus.calculateTotalHolidayBonus(dataSet1), .050);
		assertEquals(162580.0, HolidayBonus.calculateTotalHolidayBonus(dataSet1), .075);
	}

}
