	/**
	 * Class for HolidayBonus
	 */
/*
 * Class: CMSC203 
 * Instructor: prof Thai
 * Description: utility
 * Due: 12/01/2023
 * Platform/compiler: Eclipse
 * I pledge that I have completed the programming assignment independently.
*  I have not copied the code from a student or any source. 
*  I have not given my code to any student.
*  Print your Name here: Ankit Guliani_
*/
public class HolidayBonus {
	/**
	 * Constructor creates object
	 */
	public HolidayBonus(){
		TwoDimRaggedArrayUtility BonusGetter = new TwoDimRaggedArrayUtility();
	}
	/**
	 * Creates array of bonuses
	 * @param data[][]
	 * @return double[] 
	 */
	public static double[] calculateHolidayBonus(double[][] data) {
		double[] temp = new double[10];
		for(int i = 0; i<data[].length;i++) {
			temp[i] == BonusGetter.getHighestRow(data,i);	
		}
		return temp;
		
	}
	/**
	 * Creates total of bonuses
	 * @param data[][]
	 * @return double total
	 */
	public static double calculateTotalHolidayBonus(double[][] data) {
		double total;
		for(int i = 0; i<data[].length;i++) {
			total += BonusGetter.getHighestRow(data,i);	
		}
	}
	return total;
}
