import java.io.*;
/**
 * class for utility
 */
/*
 * Class: CMSC203 
 * Instructor: prof Thai
 * Description: utility
 * Due: 12/01/2023
 * Platform/compiler: Eclipse
 * I pledge that I have completed the programming assignment independently.
*  I have not copied the code from a student or any source. 
*  I have not given my code to any student.
*  Print your Name here: Ankit Guliani_
*/

public class TwoDimRaggedArrayUtility {
	private final int MAX_ROW = 10;
	private final int MAX_COLUMN = 10;
	private String[MAX_ROW][MAX_COLUMN] tempArray= new String[][];
	/**
	 * constructor exists but is not needed for fields	
	 */
	public TwoDimRaggedArrayUtility() {
			//no details given on constructor, fields already set up;
		}
	/**
	 * reads array from file
	 * @param file
	 * @return double[][] temparray
	 * @throws FileNotFoundException
	 */
	public static double[][] readFile(File file) throws FileNotFoundException{
		PrintWriter reader = new PrintWriter(file);
		reader.open();
		for(int i = 0; i<tempArray[].length;i++) {
			for(int j = 0; j<tempArray[][].length;j++) {
				if(reader.hasNext()) {
				tempArray[i][j]==reader.nextDouble(); 
				}
			}	
		}
		reader.close();
		return tempArray;
	}
	/**
	 * writes array to file
	 * @param data
	 * @param outputFile
	 * @throws FileNotFOUndException
	 */
	public static void writeToFile(double[][] data, File outputFile) throws FileNotFOUndException{
		Scanner reader = new Scanner(outputFile);
		for(int i = 0; i<data[].length;i++) {
			for(int j = 0; j<data[][].length;j++) {
				reader.print(data[i][j]); 
			}
			reader.println();
		}
	}
	/**
	 * gets total of array
	 * @param data
	 * @return double total
	 */
	public static double getTotal(double[][] data) {
		double total;
		for(int i = 0; i<data[].length;i++) {
			for(int j = 0; j<data[][].length;j++) {
				total+=data[i][j]; 
			}	
		}
		return total;
	}
	/**
	 * gets average of array
	 * @param data
	 * @param row
	 * @return double total
	 */
	public static double getAverage(double[][] data, int row) {
		double total;
		for(int i = 0; i<data[row].length;i++) {
			for(int j = 0; j<data[row][].length;j++) {
				total+=data[i][j]; 
			}	
			return total/=row;
	}
	}
	/**
	 * gets row total
	 * @param data
	 * @param row
	 * @return double total
	 */
	public static double getRowTotal(double[][] data, int row) {
		double total;
		for(int i = 0; i<data[row].length;i++) {
			for(int j = 0; j<data[row][].length;j++) {
				total+=data[i][j]; 
				}	
		
			}
		return total;
		}
	/**
	 * 
	 * get column total
	 * @param data
	 * @param col
	 * @return total
	 */
	public static double getColumnTotal(double[][] data, int col) {
		double total;
		for(int i = 0; i<data[].length;i++) {
			for(int j = 0; j<data[i][col].length;j++) {
				total+=data[i][j]; 
			}	
			return total/=col;
	}
	}
	/**
	 * gets highest in row
	 * @param data
	 * @param row
	 * @return double highest
	 */
	public static double getHighestInRow(double[][] data, int row) {
		double highest = data[0];
		for(int i = 0; i<data[row].length;i++) {
			for(int j = 0; j<data[row][].length;j++) {
				if(data[row]<data[row+1]) {
					highest = data[row+1];
				} 
				}	
			}
		return highest;
		}
	/**
	 * gets index of highest
	 * @param data
	 * @param row
	 * @return double highest
	 */
	public static int getHighestInRowIndex(double[][] data, int row) {
		double highest = data[0];
		int maxIndex;
		for(int i = 0; i<data[row].length;i++) {
			for(int j = 0; j<data[row][].length;j++) {
				if(data[row]<data[row+1]) {
					highest = data[row+1];
					maxIndex = row+1;
				} 
				}	
		
			}
		return maxIndex;
		}
	/**
	 * gets lowest in row
	 * @param data
	 * @param row
	 * @return double lowest
	 */
	public static double getLowestInRow(double[][] data, int row) {
		double lowest = data[0];
		for(int i = 0; i<data[row].length;i++) {
			for(int j = 0; j<data[row][].length;j++) {
				if(data[row]<data[row+1]) {
					lowest = data[row];
					} 
				}	
		
			}
		return lowest;
		}
	/**
	 * gets index of lowest in row
	 * @param data
	 * @param row
	 * @return double lowest
	 */
	public static int getLowestInRowIndex(double[][] data, int row) {
		double lowest = data[0];
		int minIndex;
		for(int i = 0; i<data[row].length;i++) {
			for(int j = 0; j<data[row][].length;j++) {
				if(data[row]<data[row+1]) {
					lowest = data[row];
					minIndex = row;
					} 
				}	
		
			}
		return minIndex;
	}
	/**
	 * gets highest in column
	 * @param data
	 * @param col
	 * @return double highest
	 */
	public static double getHighestInColumn(double[][] data, int col) {
		double highest = data[0][0];
		for(int i = 0; i<data[].length;i++) {
			for(int j = 0; j<data[][col].length;j++) {
				if(data[i][col]<data[col+1]) {
					highest = data[i][col+1];
				} 
				}	
			}
		return highest;
		}
	/**
	 * gets highest in column index
	 * @param data
	 * @param col
	 * @return double highest
	 */
	public static int getHighestInColIndex(double[][] data, int col) {
		double highest = data[0][0];
		int maxIndex;
		for(int i = 0; i<data[][col].length;i++) {
			for(int j = 0; j<data[][col].length;j++) {
				if(data[i][col]<data[][col+1]) {
					highest = data[i][col+1];
					maxIndex = col+1;
				} 
				}	
		
			}
		return maxIndex;
		}
	/**
	 * gets lowest in column
	 * @param data
	 * @param col
	 * @return double lowest
	 */
	public static double getLowestInColumn(double[][] data, int col) {
		double lowest = data[0][0];
		for(int i = 0; i<data[].length;i++) {
			for(int j = 0; j<data[][col].length;j++) {
				if(data[i][col]<data[col+1]) {
					lowest = data[i][col];
				} 
				}	
			}
		return lowest;
		}
	/**
	 * gets index of lowest in column
	 * @param data
	 * @param col
	 * @return double lowest
	 */
	public static int getLowestInColIndex(double[][] data, int col) {
		double lowest = data[0][0];
		int minIndex;
		for(int i = 0; i<data[][col].length;i++) {
			for(int j = 0; j<data[][col].length;j++) {
				if(data[i][col]<data[][col+1]) {
					lowest = data[i][col];
					minIndex = col;
				} 
				}	
		
			}
		return minIndex;
		}
	/**
	 * gets highest in array
	 * @param data
	 * @return double highest
	 */
	public static double getHighestInArray(double[][] data) {
		double highest = data[0][0];
		for(int i = 0; i<data[].length;i++) {
			for(int j = 0; j<data[][].length;j++) {
				if(data[i][j]<data[i+1][j+1]) {
					highest = data[i+1][j+1];
				} 
			}	
		}
		return highest;
	}
	/**
	 * gets lowest in array
	 * @param data
	 * @return double lowest
	 */
	public static double getLowestInArray(double[][] data) {
		double Lowest = data[0][0];
		for(int i = 0; i<data[].length;i++) {
			for(int j = 0; j<data[][].length;j++) {
				if(data[i][j]<data[i+1][j+1]) {
					Lowest = data[i][j];
				} 
			}	
		}
		return Lowest;
	}
	}
	
