/**
 * Procedure creates and sets up information about the procedure for the patient.
 * This includes name, date, practitioner, and cost
 */
public class Procedure {
	private String procedureName;
	private String procedureDate;
	private String procedurePractitioner;
	private String procedureCost;
	/**
	 * Constructs a procedure object with all fields set to empty strings.
	 */
	public Procedure() {
	String procedureName = "";
	String procedureDate = "";
	String procedurePractitioner = "";
	String procedureCost = "";

	}
	/**
	 * Constructs a procedure object and takes a name and date
	 * @param name is the name of the procedure
	 * @param date is the date of the procedure
	 */
	public Procedure(String name, String date) {
		procedureName = name;
		procedureDate = date;
	}
	/**
	 * Constructs a procedure object and takes a name, date, practitioner, and cost
	 * @param name  is the name of the procedure
	 * @param date  is the date of the procedure
	 * @param practitioner  is the practitioner of the procedure
	 * @param cost  is the cost of the procedure
	 */
	public Procedure(String name, String date, String practitioner, String cost) {
		procedureName = name;
		procedureDate = date;
		procedurePractitioner = practitioner;
		procedureCost = cost;
	}
	/**
	 * Gets the procedure name
	 * @return is the procedureName field
	 */
	public String getName() {
		return procedureName;
	}
	/**
	 * Gets the procedure date
	 * @return is the procedureDate field
	 */
	public String getDate() {
		return procedureDate;
	}
	/**
	 * Gets the procedure practitioner
	 * @return is the procedurePractitioner field
	 */
	public String getPractitioner() {
		return procedurePractitioner;
	}
	/**
	 * Gets the procedure cost
	 * @return is the procedureCost field
	 */
	public String getCost() {
		return procedureCost;
	}
	/**
	 * Sets the procedure name
	 * @param name takes a name
	 */
	public void setName(String name) {
		procedureName = name;
	}
	/**
	 * Sets the procedure date
	 * @param date takes a date
	 */
	public void setDate(String date) {
		procedureDate = date;
	}
	/**
	 * Sets the procedure practitioner
	 * @param practitioner takes a practitioner
	 */
	public void setPractitioner(String practitioner) {
		procedurePractitioner = practitioner;
	}
	/**
	 * Sets the procedure cost
	 * @param cost takes a cost
	 */
	public void setCost(String cost) {
		procedureCost = cost;
	}
	/**
	 * Makes a string with all procedural info
	 * @return is a string with the full info for the procedure
	 */
	public String toString() {
		String procedureInfo = getName() + " " + getDate() + " " + getPractitioner() + " " + getCost();
	}
}
