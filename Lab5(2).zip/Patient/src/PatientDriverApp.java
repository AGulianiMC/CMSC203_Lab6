/*
 * Class: CMSC203 
 * Instructor: Prof. Thai
* *Description: (Patient sets up info for a patient, Procedure creates blueprint for procudure info, 
* *and PatientDriverApp runs and displays both. )
 * Due: 10/06/2023
 * Platform/compiler:Eclipse
 * I pledge that I have completed the programming 
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
   Print your Name here: _Ankit Guliani__
*/
/**Class creates objects with constructors to run methods off of
 * 
 */
public class PatientDriverApp {
	Patient patient1 = new Patient("Naruto", "Hokage", "Uzumaki");
	Procedure procedure1 = new Procedure();
	Procedure procedure2 = new Procedure("fixHalitosis", " 01/01/23");
	Procedure procedure3 = new Procedure("chippedFingerNail", " 01/01/23", "Tom", "$200");
	
	
	
	procedure1.setName("Gary");
	procedure2.setDate("10/25/2023");
	procedure3.setPractitioner("Harold");
	/**
	 * Displays the patient's info
	 * @return the patient's info
	 */
	public String displayPatient() {
		 System.out.println(patient1.toString());
	}
	/**
	 * Displays the procedure info
	 * @return the procedure info
	 */
	public String displayProcedure() {
		 System.out.println(procedure1.toString());
		 System.out.println(procedure2.toString());
		 System.out.println(procedure3.toString());
	}
	/**
	 * Calculates total charges for the procedure
	 * @param first is the charge of the first procedure
	 * @param second is the charge of the first procedure
	 * @param third is the charge of the first procedure
	 * @return is the full list of the charges(not added up)
	 */
	public String calculateTotalCharges(Procedure first, Procedure second, Procedure third) {
		String totalCost = first.getCost()+ ",.." + second.getCost() + ",.." +  third.getCost();
		 System.out.println(totalCost);
	}
	
	// example methods used to populate data into the objects
	//patient1.setName("Thomas");
	// displayPatient();
	//patient1.setState("Missouri");
	//displayPatient();
	//patient1.setCity("chicago");
	//displayPatient();
	//procedure1.setName("dirtyHair");
	//displayProcedure();
	//procedure2.setDate("01/002/2025");
	//displayProcedure();
	
	
}
