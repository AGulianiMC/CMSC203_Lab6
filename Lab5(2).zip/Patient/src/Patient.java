/**
 * Sets up info for the patient. Creates variable fields to hold data.
 */
public class Patient {
	private String firstName;
	private String middleName;
	private String lastName;
	private String streetAddress;
	private String city;
	private String state;
	private String zipCode;
	private String phoneNumber;
	private String emergName;
	private String emergNum;
	/**
	 * Constructor that doesn't take arguments and sets everything to an empty String.
	 */
	public Patient() {
	String firstName = "";
	String middleName = "";
	String lastName = "";
	String streetAddress = "";
	String city = "";
	String state = "";
	String zipCode = "";
	String phoneNumber = "";
	String emergName = "";
	String emergNum = "";
	}
	/**
	 * Constructor that takes arguments to set up the Patient name.
	 * @param fName
	 * @param mName
	 * @param lName
	 */
	public Patient(String fName, String mName, String lName) {
		firstName = fName;
		middleName = mName;
		lastName = lName;
	}
	/**
	 * Gets the patient's address.
	 * @return The streetAddress variable.
	 */
	public String getAddress() {
		return streetAddress;
	}
	/**
	 * Gets the patient's city.
	 * @return The city variable 
	 */
	public String getCity() {
		return city;
	}
	/**
	 * Gets the patient's state.
	 * @return The state variable 
	 */
	public String getState() {
		return state;
	}
	/**
	 * Gets the patient's zip code.
	 * @return The zipCode variable 
	 */
	public String getZipCode() {
		return zipCode;
	}
	/**
	 * Gets the patient's phone number.
	 * @return The phoneNumber variable 
	 */
	public String getPhoneNumber() {
		return phoneNumber;
	}
	/**
	 * Gets the patient's emergency name.
	 * @return The emergName variable 
	 */
	public String getEmergName() {
		return emergName;
	}
	/**
	 * Gets the patient's emergency number.
	 * @return The emergNum variable 
	 */
	public String getEmergNum() {
		return emergNum;
	}
	/**
	 *Sets the patient's address. 
	 * @param ad1 takes the address input.
	 */
	public void setAddress(String ad1) {
		streetAddress = ad1;
	}
	/**
	 *Sets the patient's city. 
	 * @param town takes the city input.
	 */
	public void setCity(String town) {
		city = town;
	}
	/**
	 *Sets the patient's state. 
	 * @param province takes the state input.
	 */
	public void setState(String province) {
		state = province;
	}
	/**
	 *Sets the patient's zip code. 
	 * @param placeNumber takes the zip code input.
	 */
	public void setZipCode(String placeNumber) {
		zipCode = placeNumber;
	}
	/**
	 *Sets the patient's phone number. 
	 * @param num takes the phone number input.
	 */
	public void setPhoneNumber(String num) {
		phoneNumber = num;
	}
	/**
	 *Sets the patient's emergency name. 
	 * @param emName takes the emergency name input.
	 */
	public void setEmergName(String emName) {
		emergName = emName;
	}
	/**
	 *Sets the patient's emergency number. 
	 * @param emNum takes the emergency number input.
	 */
	public void setEmergNum(String emNum) {
		emergNum = emNum;
	}
	/**
	 * Builds a full name of the patient using previous methods.
	 * @param fName takes first name
	 * @param mName takes middle name
	 * @param lName takes last name
	 * @return is of the full name
	 */
	public String buildFullName(String fName, String mName, String lName) {
		String fullName = fName + " " + mName + " " + lName;
	}
	/**
	 * Builds the patient's address
	 * @param ad1 is the street address
	 * @param town is the city
	 * @param province is the state
	 * @param num is the phone number
	 * @return is the full address
	 */
	public String buildAddress(String ad1, String town, String province, String num) {
		String fullAddress = ad1 + " " + town + " " + province + " " + num;
	}
	/**
	 * Builds the emergency contact info 
	 * @param emName is the emergency name
	 * @param emNum is the emergency number
	 * @return is the full emergency contact
	 */
	public String buildEmergencyContact(String emName, String emNum) {
		String emergencyContact = emName + " " + emNum;
	}
	/**
	 * Creates a full string with all of the patient's info
	 * @return is of the full string
	 */
	public String toString() {
		String fullInfo = buildFullName(firstName, middleName, lastName) + " " + buildAddress(streetAddress, city, state, zipCode)+ " " + buildEmergencyContact(emergName, emergNum);
		return fullInfo;
	}
	
	
}
