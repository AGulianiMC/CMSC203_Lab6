/*
 * Class: CMSC203 
 * Instructor: Prof. Thai
 * Description: Sets up management company for properties and plots
 * Due: 11/10/2023
 * Platform/compiler:
 * I pledge that I have completed the programming 
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
   Print your Name here:Ankit Guliani
*/

public class ManagementCompany {
	static final int MAX_PROPERTY;
	static final int MGMT_DEPTH;
	static final int MGMT_WIDTH;
	// Was necessary to create variables to store data between calls
	int maxCount;
	String name1;
	String taxID1;
	double mgmFee1;
	int x1;
	int y1;
	int width1;
	int depth1;
	Property[MGMT_WIDTH][MGMT_DEPTH] newSet1 = new Property[][];
	ManagementCompany newComp = new ManagementCompany();
	Plot newPlot = new Plot(maxCount, maxCount);
	/**
	 * Management Company Constructor which creates new company, plot, and property array objects
	 */
	public ManagementCompany() {
		ManagementCompany company1 = new ManagementCompany();
		Plot newPlot = new Plot(maxCount, maxCount);
		Property[MGMT_DEPTH][MGMT_WIDTH] newSet = new Property[][];
	}
	/**
	 * Management Company Constructor which creates new company, plot, and property array objects and sets name, taxID, and mgmFee parameters
	 * @param sets name, taxID, and mgmFee parameters
	 */
	public ManagementCompany(String name, String taxID, double mgmFee) {
		ManagementCompany company1 = new ManagementCompany();
		Plot newPlot = new Plot(maxCount, maxCount);
		Property[MGMT_DEPTH][MGMT_WIDTH] newSet = new Property[][];
		name1 = name;
		taxID1 = taxID;
		mgmFee1 = mgmFee;
	}
	/**
	 * Management Company Constructor which creates new company, plot, and property array objects and sets name, taxID, mgmFee, x, y, width, and depth fields
	 * @param sets name, taxID, mgmFee, x, y, width, and depth fields
	 */
	public ManagementCompany(String name, String taxID, double mgmFee, int x, int y, int width, int depth) {
		ManagementCompany company1 = new ManagementCompany();
		Plot newPlot = new Plot(maxCount, maxCount);
		Property[MGMT_DEPTH][MGMT_WIDTH] newSet = new Property[][];
		name1 = name;
		taxID1 = taxID;
		mgmFee1 = mgmFee;
		x1 = x;
		y1 = y;
		width1 = width;
		depth1 = depth;
	}
	/**
	 * Management Company Constructor which creates copy of taken object
	 * @param takes otherCompany objects
	 */
	public ManagementCompany(ManagementCompany otherCompany) {
		ManagementCompany company2 = new ManagementCompany(otherCompany);
	}
	/**
	 * addProperty adds property to properties array with name, city, rent, owner, x, y, width, and depth parameters
	 * @param name, city, rent, owner, x, y, width, and depth parameters
	 */
	public int addProperty(String name, String city, double rent, String owner, int x, int y, int width, int depth) {
		newSet1[width][depth] = new Property(name, city, rent, owner, x, y, width, depth);
		if(newSet1[width][0].length == MAX_WIDTH && newSet1[0][depth].length) == MAX_DEPTH){
			return -1;
		}
		else if(newSet1[width][depth]==null) {
			return -2;
		}
		else if(newComp.encompasses(newSet1[width][depth])==false) {
			return -3;
		}
		else if(newSet1[width][depth].overlaps(newSet1)) {
			return -4;
		}
		else {
			return width;
		}
	}
	/**
	 * removes last property in properties array
	 */
	public void removeLastProperty() {
	newSet1[MAX_WIDTH][MAX_DEPTH-1]= null;	
	}
	/**
	 * checks if properties array is full
	 * @return boolean if array is full or not
	 */
	public boolean isPropertiesFull() {
		newSet1[MAX_WIDTH][MAX_DEPTH-1]= null;
		if(newSet1[MAX_WIDTH][0].length == MAX_WIDTH && newSet1[0][MAX_DEPTH].length) == MAX_DEPTH){
			return true;
		}
		else {
			return false;
		}
		}
	/**
	 * gets amount of properties in array
	 * @return int of count for array
	 */
	public int getPropertiesCount() {
		int count = 0;
		for(int i = 0; i< newSet1[MAX_WIDTH].length;i++) {
			for(int j = 0; i< newSet1[i].length;j++) {
				count += 1;
			}
		}
		return count;
	}
	/**
	 * finds total rent for all properties
	 * @return double as amount for totalRent
	 */
	public double getTotalRent() {
		int totalRent = 0;
		for(int i = 0; i< newSet1[MAX_WIDTH].length;i++) {
			for(int j = 0; i< newSet1[i].length;j++) {
				totalRent += newSet1[i][j].getRent();
			}
		}
		return totalRent;
	}
	/**
	 * finds highest rent property in array
	 * @return property object with highest rent
	 */
	public Property getHighesetRentProperty() {
		Property highest = newSet1[0][0];
		for(int i = 0; i< newSet1[MAX_WIDTH].length;i++) {
			for(int j = 0; i< newSet1[i].length;j++) {
				if(newSet1[i][j].getRent() > highest.getRent()) {
					highest = newSet1[i][j];
				}
			}
		}
		return highest;
	}
	/**
	 * tests if management fee is valid
	 * @return boolean if fee is valid or not
	 */
	public boolean isManagementFeeValid() {
		if (mgmFee>0 && mgmFEE<100) {
			return true;
		}
		else {
			return false;
		}
		
	}
	/**
	 * gets name of company
	 * @return name1 for company
	 */
	public String getName() {
		return name1;
	}
	/**
	 * gets taxID1 of company
	 * @return taxID1 for company
	 */
	public String getTaxID() {
		return taxID1;
	}
	/**
	 * gets properties array
	 * @return newSet1[][] array
	 */
	public Property[] getProperties() {
		return newSet1[][];

	}
	/**
	 * gets amount of mgmfee
	 * @return double mgmfee1 
	 */
	public double getMgmFeePer() {
		return mgmFee1;
	}
	/**
	 * gets plot
	 * @return plot as newPlot
	 */
	public Plot getPlot() {
		return newPlot;
	}
	/**
	 * gets string info of company and plot
	 * @return String newString 
	 */
	public String toString() {
		String newString = new String (name1 + ", " + taxID1 + ", " + newSet1[][].name1+ ", " + newSet1[][].city1+ ", " + newSet1[][].owner1+ ", " + newSet1[][].rentAmount1);
		return newString;
	}
}

