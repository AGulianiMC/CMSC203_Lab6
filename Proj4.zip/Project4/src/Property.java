/*
 * Class: CMSC203 
 * Instructor: Prof. Thai
 * Description: Sets up Properties to be processed
 * Due: 11/10/2023
 * Platform/compiler:
 * I pledge that I have completed the programming 
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
   Print your Name here:Ankit Guliani
*/

public class Property {
	//Needed to create other fields to store data in between calls
	String propertyName1;
	String city1;
	double rentAmount1;
	String owner1;
	Plot firstPlot;
	/**
	 * constructor which creates a plot and property objects
	 */
	public Property() {
		Plot newPlot = new Plot();
		Property newProperty = new Property();
	}
	/**
	 * constructor which creates plot and property objects and sets params to fields
	 * @param propertyName set to propertyName1
	 * @param city set to city1
	 * @param rentAmount set to rentAmount1
	 * @param owner set to owner1
	 */
	public Property(String propertyName, String city, double rentAmount, String owner) {
		Plot newPlot = new Plot();
		Property newProperty = new Property();
		
		propertyName1 = propertyName;
		city1 = city;
		rentAmount1 = rentAmount;
		owner1 = owner;
	}
	/**
	 * constructor which creates plot and property objects and sets params to fields
	 * @param propertyName
	 * @param city
	 * @param rentAmount
	 * @param owner
	 * @param x
	 * @param y
	 * @param width
	 * @param depth
	 */
	public Property(String propertyName, String city, double rentAmount, String owner, int x, int y,int width, int depth) {
		Plot newPlot = new Plot(x, y, width, depth);
		Property newProperty = new Property();
		
		propertyName1 = propertyName;
		city1 = city;
		rentAmount1 = rentAmount;
		owner1 = owner;
	}
	/**
	 * copies input object
	 * @param otherProperty is input to be copied
	 */
	public Property(Property otherProperty) {
		Property secondProperty = new Property(otherProperty);
	}
	/**
	 * gets the plot
	 * @return firstplot object
	 */
	public Plot getPlot() {
		return firstPlot;
	}
	/**
	 * gets property name
	 * @return propertyName1
	 */
	public String getPropertyName() {
		return propertyName1;
	}
	/**
	 * gets city name
	 * @return city1
	 */
	public String getCity() {
		return city1;
	}
	/**
	 * gets rent amount
	 * @return rent amount1
	 */
	public double getRentAmount() {
		return rentAmount1;
	}
	/**
	 * gets owner name
	 * @return owner1
	 */
	public String getOwner() {
		return owner1;
	}
	/**
	 * gets string containing all plot info
	 * @return string containing propertyName1, city1, owner1, rentAmount1
	 */
	public String toString() {
		String newString = new String (propertyName1 + ", " + city1 + ", " + owner1 + ", " + rentAmount1);
		return newString;
	}
}
