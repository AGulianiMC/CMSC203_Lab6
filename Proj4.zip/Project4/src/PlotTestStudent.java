import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class PlotTestStudent {

	private Plot firstPlot, secondPlot, thirdPlot;

	
	public void setUp() throws Exception {
		firstPlot = new Plot(7, 18, 25, 28);
		secondPlot = new Plot(10, 97, 32, 21);
		thirdPlot = new Plot(8, 9, 10, 11);
	}

	
	public void tearDown() throws Exception {
		firstPlot = secondPlot = thirdPlot = null;
	}

	
	public void overLapTest() {
		assertTrue(firstPlot.overlaps(secondPlot));
		assertTrue(firstPlot.overlaps(thirdPlot));
		assertTrue(secondPlot.overlaps(firstPlot));
		assertTrue(secondPlot.overlaps(thirdPlot));
		assertTrue(thirdPlot.overlaps(secondPlot));
		assertTrue(thirdPlot.overlaps(firstPlot));
	}
	
	
	public void testToString() {
		assertEquals("7,18,25,28",firstPlot.toString());	
		assertEquals("10,97,32,21",secondPlot.toString());
		assertEquals("8,9,10,11",thirdPlot.toString());	
	}

}
