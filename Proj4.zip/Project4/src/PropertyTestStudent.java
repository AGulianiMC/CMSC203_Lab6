import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class PropertyTestStudent {

	
	void setUp() throws Exception {
		propertyOne = new Property("Apple", "Tornado", 5000.00, "Capital One");
	}

	
	void tearDown() throws Exception {
		propertyOne = null;
	}

	
	void propertyTest() {
		assertEquals("Property ABC", propertyOne.getPropertyName());
		assertEquals("TomatoPaste", propertyOne.getPropertyName());
		assertEquals("OnionJuice", propertyOne.getPropertyName());
		
	}

	
	void rentTest() {
		assertEquals(5000.00, propertyOne.getRentAmount());
		assertEquals(8000.00, propertyOne.getRentAmount());
		assertEquals(10000.00, propertyOne.getRentAmount());

	}

	
	void plotTest() {
		assertEquals(5, propertyOne.getPlot().getX());
		assertEquals(8, propertyOne.getPlot().getY());
		assertEquals(12, propertyOne.getPlot().getWidth());
		assertEquals(15, propertyOne.getPlot().getDepth());
		assertEquals(14, propertyOne.getPlot().getX());
		assertEquals(46, propertyOne.getPlot().getY());
		assertEquals(28, propertyOne.getPlot().getWidth());
		assertEquals(22, propertyOne.getPlot().getDepth());
		
	}

	
	void toStringTest() {
		assertEquals("Apple,Tornado,CapitalOne,5000.0",propertyOne.toString());	
	}

}
