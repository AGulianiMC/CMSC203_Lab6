import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class ManagementCompanyTestStudent {

	Property property1;
	ManagementCompany company1 ; 
	
	public void setUp() throws Exception {
		company1= new ManagementCompany("50050", "35000",12);
	}

	
	public void tearDown() throws Exception {
		company1=null;
	}

	
	public void propertyPlusTest() {
		property1 = new Property ("RealProp", "CocaCola", 2000, "Batman",8,7,6,4);		 
		assertEquals(company1.addProperty(property1),5,7);	
	}
	
	
	public void propertyAmountTest() {
		property1 = new Property ("RealProp", "CocaCola", 2000, "Batman",8,7,6,4);		 
		assertEquals(company1.addProperty(sampleProperty),0,0);	
		assertEquals(company1.getPropertiesCount(), 8);
	}

	
	public void testToString() {
		property1 = new Property ("RealProp", "CocaCola", 2000, "Batman",8,7,6,4);
		assertEquals(company1.addProperty(property1), 10);	
		String toStringTest = "Company, 50050: 35000\n"
				+ "RealProp,CocaCola,Baatman,2000.0 fee: 170.00";
		assertEquals(toStringTest, company1.toString());
				
	}

}
