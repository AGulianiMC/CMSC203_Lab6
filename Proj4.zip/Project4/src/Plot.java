/*
 * Class: CMSC203 
 * Instructor: Prof. Thai
 * Description: Sets up plots to be processed
 * Due: 11/10/2023
 * Platform/compiler:
 * I pledge that I have completed the programming 
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
   Print your Name here:Ankit Guliani
*/
public class Plot {
	//extra fields were required to store data between calls
	int depth1;
	int width1;
	int x1;
	int y1;
	/**
	 * no arg constructor sets up basic values for depth and width
	 */
	public Plot() {
		depth1 = 1;
		width1 = 1;
	}
	/**
	 *  constructor sets up  values for x,y, depth, width
	 *  @param x, y, width, depth for object
	 */
	public Plot(int x, int y, int width, int depth) {
		x1 = x;
		y1=y;
		depth1 = depth;
		width1 = width;
		/**
		 * constructor makes a copy of another plot
		 */
	}
	public Plot(Plot otherPlot) {
		Plot plot1 = new Plot(otherPlot);
	}
	/**
	 * tests if plots overlap
	 * @param plot takes a plot object to test
	 * @return true or false if the overlap
	 */
	public boolean overlaps(Plot plot) {
		if(this.x1>plot.x1||this.y1>plot.y1) {
		return true;	
		}
		else {
			return false;
		}
	}
	/**
	 * tests if one plot encompasses another
	 * @param plot object to test
	 * @return true or false if they encompass
	 */
	public boolean encompasses(Plot plot) {
		if(this.depth1>plot.depth1||this.width1>plot.width1) {
			return true;	
			}
			else {
				return false;
			}
	}
	/**
	 * sets x to x1
	 * @param x is input
	 */
	public void setX(int x) {
		x1 = x;
	}
	/**
	 * sets y to y1
	 * @param y is input
	 */
	public void setY(int y) {
		y1 = y;
	}
	/**
	 * sets width to width1
	 * @param width is input
	 */
	public void setWidth(int width) {
		width1 = width;
	}
	/**
	 * sets depth to depth1
	 * @param depth is input
	 */
	public void setDepth(int depth) {
		depth1 = depth;
	}
	/**
	 * gets x1
	 * @return value of x1
	 */
	public int getX() {
		return x1;
	}
	/**
	 * gets y1
	 * @return value of y1
	 */
	public int getY() {
		return y1;
	}
	/**
	 * gets width1
	 * @return value of width1
	 */
	public int getWidth() {
		return x1;
	}
	/**
	 * gets depth1
	 * @return value of depth1
	 */
	public int getDepth() {
		return depth1;
	}
	/**
	 * gets string of plot info
	 * @return string containing x1, y1, width1, depth1
	 */
	public String toString() {
		String newString = new String(x1 + ", " + y1+ ", " + width1 + ", " + depth1);
		return newString;
	}
	
}
