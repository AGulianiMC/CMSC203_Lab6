import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
/**
 * Student Test Cases
 */
class CryptoManagerStudentTestCase {
	/**
	 * Sets up newManager object
	 */
	public void setUp() {
		CryptoManager newManager = new CryptoManager();
	}
	@Test
	void test() {
		fail("Not yet implemented");
	}
	/**
	 * Tests for returned inBound Strings
	 */
	public void testBounds() {
	assertTrue(CryptoManager.isStringInBounds("Test"));
	assertTrue(CryptoManager.isStringInBounds("Human"));
	assertTrue(CryptoManager.isStringInBounds("HelloWorld"));
	assertTrue(CryptoManager.isStringInBounds("!!!!!"));
	}
	/**
	 * Tests caesar encryptions
	 */
	public void testCaesarE() {
		assertEquals(caesarEncryption("HelloWorld",25),"WHOKLDFJSL");
		assertEquals(caesarEncryption("Humans",25),"ajselkfjL");
		assertEquals(caesarEncryption("MynameisHenry",35),"MAJJUDIFFIIEJH");
		assertEquals(caesarEncryption("Breathing",10),"EJSHSOFFD");

	}
	/**
	 * Tests caesar decryptions
	 */
	public void testCaesarD() {
		assertEquals(caesarDecryption("WHOKLDFJSL",25),"HelloWorld");
		assertEquals(caesarDecryption("ajselkfjL",25),"Humans");
		assertEquals(caesarDecryption("MAJJUDIFFIIEJH",35),"MynameisHenry");
		assertEquals(caesarDecryption("EJSHSOFFD",10),"Breathing");
	}
	/**
	 * tests bellaso encryptions
	 */
	public void testBellasoE() {
		assertEquals(BellasoEncryption("ThisLandIs",15),"OJLAJFLLJKJF");
		assertEquals(BellasoEncryption("YourLand",20),"FJLKKJKENN");
		assertEquals(BellasoEncryption("ThisLandIs",25),"SOJLKJFLKJDF");
		assertEquals(BellasoEncryption("MYLAND",30),"PSJDKJLD");

	}
	/**
	 * tests bellaso decryptions
	 */
	public void testBellasoD() {
		assertEquals(BellasoDecryption("OJLAJFLLJKJF",15),"ThisLandIs");
		assertEquals(BellasoDecryption("FJLKKJKENN",20),"YourLand");
		assertEquals(BellasoDecryption("SOJLKJFLKJDF",25),"ThisLandIs");
		assertEquals(BellasoDecryption("PSJDKJLD",30),"MYLAND");
	}

	public void tearDown() {
		
	}
}
