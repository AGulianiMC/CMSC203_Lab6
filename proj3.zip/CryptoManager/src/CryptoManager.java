/*
 * Class: CMSC203 
 * Instructor:
 * Description: (Give a brief description for each Class)
 * Due: 10/27/2023
 * Platform/compiler: Eclipse
 * I pledge that I have completed the programming  assignment independently. 
*  I have not copied the code from a student or any source. 
*  I have not given my code to any student.
*  Print your Name here: Ankit Guliani
*/

public class CryptoManager {
	/**
	 * tests if a string is in bounds using numeric values from the ascii table
	 * @param plaintext is an entered text
	 */
	public static boolean isStringInBounds(String plainText) {
		if(32<=plainText<=177) {
			return true;
		}
		else {
			return false;
		}
	}
	/**
	 * encrypts a string using caesar encryption
	 * @param plainText is the user input
	 * @param key is the key to adjust the text
	 * @return is the new encrypted text
	 */
	public static String caesarEncryption(String plainText, int key) {
		String[] letters = new String[plainText.length()];
		char holder;
		int holder2;
		String newString;
		if(isStringInBounds(plainText) == true) {
			for(int i = 0; i<plainText.length();i++) {
				holder=letters[i].charAt(0);
				holder2 = holder + key;
				holder = (char)holder2;
				letters[i] = holder;
				newString += letters[i];
				return newString;
			}
		}
	}
	/**
	 * Decrypts text that has been encrypted in caesar style
	 * @param encryptedText is the encryptedtext being put back in
	 * @param key is the key originally used to revert the string
	 * @return is the decrypted string
	 */
	public static String caesarDecryptionString (String encryptedText, int key) {
	String[] letters = new String[encryptedText.length()];
	String newString;
	if(isStringInBounds(encryptedText)==true) {
	char holder;
	int holder2;
	for(int i = 0; i<encryptedText.length();i++) {
		holder=letters[i].charAt(0);
		holder2 = holder - key;
		holder = (char)holder2;
		letters[i] = holder;
		newString += letters[i];
		return newString;
		}
	}	
	}
	/**
	 * encrypts a string using bellaso encryption
	 * @param plainText is the user input
	 * @param bellasoStr is the string key to adjust the text
	 * @return is the new encrypted text
	 */
	public static String bellasoEncryption(String plainText, String bellasoStr) {
		String[] letters = new String[plainText.length()];
		int[]bellasoCount = new int[bellasoStr.length()];
		String newString;
		if(isStringInBounds(plainText)==true) {
		char holder;
		int holder2;
		int holder3;
		for(int i = 0; i<plainText.length();i++) {
			holder=letters[i].charAt(0);
			holder3 = (int)bellasoStr.charAt(i%bellasoStr.length());
			holder2 = (holder3 + (int)holder)-holder3-1;
			holder = (char)holder2;
			letters[i] = holder;
			newString += letters[i];
			return newString;
			}
		}
	}
	/**
	 * decrypts a string using bellaso encryption
	 * @param encryptedText is the user input
	 * @param bellasoStr is the string key to adjust the text
	 * @return is the decrypted text
	 */
	public static String bellasoDecryption(String encryptedText, String bellasoStr) {
		String[] letters = new String[encryptedText.length()];
		int[]bellasoCount = new int[bellasoStr.length()];
		String newString;
		if(isStringInBounds(encryptedText)==true) {
		char holder;
		int holder2;
		int holder3;
		for(int i = 0; i<encryptedText.length();i++) {
			holder=letters[i].charAt(0);
			holder3 = (int)bellasoStr.charAt(i%bellasoStr.length());
			holder2 = ((int)holder-holder3)+1;
			holder = (char)holder2;
			letters[i] = holder;
			newString += letters[i];
			return newString;
			}
		}
	}
}
